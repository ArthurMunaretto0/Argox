window.DEFAULT_VENDEDORES = {
  1:"Wagner",2:"Rogerio",3:"Eugenio",4:"Ricardo",5:"Fabio",6:"Gustavo",7:"Cadore",8:"Luiz",
  9:"Fucaro",10:"Claudio",11:"Jonathan",12:"Willian",13:"Sandro",14:"Marcio",15:"Roberto",
  16:"Fernando",17:"Fernando",18:"Scalco",19:"Gilmar",20:"Goiano",21:"Ney",22:"Serginho",
  23:"Adriana",24:"Ginete",25:"Crespar",26:"Herweg",27:"Ricardo Orient",28:"Technos",29:"Champion"
};
window.DEFAULT_OBJETOS = {
  11:"Anel",12:"Brinco",13:"Corrente",14:"Pulseira",15:"Pingente",16:"Relogio",
  17:"Relo. Parede",18:"Reloj. Desp",19:"Cuia",20:"Bomba",21:"Faca",22:"Cartão"
};
window.DEFAULT_MATERIAIS = { 1:"Ouro 10k",2:"Ouro 18k",3:"Prata",4:"Folheado",5:"Aço",6:"Inox" };
