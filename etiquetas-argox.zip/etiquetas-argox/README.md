# Gerador de Etiquetas – Argox OS-214plus

Projeto em HTML/CSS/JS para gerar etiquetas com código de barras no padrão definido:

```
OO MM VV AA CCCCC
```

- **OO**: Objeto (11–22)
- **MM**: Material (01–06)
- **VV**: Vendedor (01–29)
- **AA**: Ano (dois dígitos)
- **CCCCC**: custo com 1 casa decimal **sem ponto** (ex.: 124.9 -> 01249)

## Como usar
1. Abra `index.html` no navegador (Chrome recomendado).
2. Preencha os campos e clique **Gerar código**.
3. Clique **Imprimir** para enviar à sua Argox OS-214plus (ou qualquer impressora instalada).
4. Bipe um código na seção **Decodificar** para ver os dados legíveis.

## Dicas de impressão (Argox OS-214plus)
- Configure no driver o tamanho do rótulo (ex.: 58x30mm) conforme o rolo.
- Desative margens do navegador e cabeçalho/rodapé.
- Se o corte/avançar sair desalinhado, ajuste a **largura/altura** nas opções de impressão e faça a calibração no driver.

## Trocar simbologia
O projeto usa **Code 39** (robusto e simples). Se quiser **Code 128**, me avise que envio o encoder.
#   A r g o x  
 